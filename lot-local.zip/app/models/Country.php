<?php

class Country extends \Eloquent {
    protected $fillable = [];


}
<?php

class State extends \Eloquent {
    protected $fillable = [];


}
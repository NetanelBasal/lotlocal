<?php

class Contact extends \Eloquent {
	protected $guarded = ['id'];

}
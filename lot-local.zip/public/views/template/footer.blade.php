
<footer>
  <div class="wrap">
    <div class="inside">
    <section>
      <div class="row">
        <img src="images/footer.png" alt="lotteryClick" class="img-responsive">
      </div>
       <div class="row text-center mt">
        <a><i class="fa fa-facebook"></i></a>
        <a><i class="fa fa-google-plus"></i></a>
        <a><i class="fa fa-twitter"></i></a>
        <a><i class="fa fa-youtube"></i></a>
       </div>
    </section><!-- logo and social -->

    <section>
      <div class="row mt">
         <img src="images/cards.png" alt="cards" class="cards">
      </div>
      <div class="row mt">
        <div class="footer-links">
          <!-- <p><a class="main-color" ui-sref="operatorDash.langs">Config</a></p>
          <p><a class="main-color" ui-sref="promosPanel">Promos</a></p> -->
          <p><a ui-sref="contact-us">About LotteryClick</a></p>
          <p><a ui-sref="contact-us">Contact LotteryClick</a></p>
          <p><a ui-sref="policy">Privacy Policy</a></p>
          <p><a ui-sref="terms">Terms & Conditions</a></p>
          <p><a href="http://partners.lotterylabel.com" target="_blank">Affiliate Program</a></p>
         <!--  <p ng-if="userService.user.type == 'operator'"><a class="main-color" ui-sref="contacts-list">Contacts</a></p> -->
         <!--  
          
          <p><a ui-sref="faq">FAQ</a></p> -->
          <!-- <p><a ui-sref="contact-us">Contact Us</a></p> -->

        </div>
         <div class="footer-links">
          <p class="main-color">Official Lottery</p>
          <p><a href="">Play MegaMillions</a></p>
          <p><a href="">Play PowerBall</a></p>
          <p><a href="">Play EuroMiilions</a></p>
          <p><a href="">Play EuroJackpot</a></p>
          <p><a href="">Play LaPrimitiva</a></p>
          <p><a href="">Play SuperEnalotto</a></p>
        </div>
         <div class="footer-links">
          <p class="main-color">Lottery Results & info</p>
          <p><a href="">MegaMillions results&info</a></p>
          <p><a href="">PowerBall results&info</a></p>
          <p><a href="">EuroMiilions results&info</a></p>
          <p><a href="">EuroJackpot results&info</a></p>
          <p><a href="">LaPrimitiva results&info</a></p>
          <p><a href="">SuperEnalotto results&info</a></p>
        </div>
         <div class="footer-links">
          <p><a ui-sref="faq">FAQ</a></p>
          <p>Lottery news</p>
          <p>Lottery blog</p>
          <p>Lottery RSS</p>
        </div>
      </div>
      <!-- <div class="row">
        <div>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo</div>
      </div> -->
    </section>
    </div>
  </div>
</footer>
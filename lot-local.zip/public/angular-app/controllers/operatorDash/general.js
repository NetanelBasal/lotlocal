module.exports = ['$scope',
    function($scope) {

$scope.lang = $scope.config.langs[0];

    }
]
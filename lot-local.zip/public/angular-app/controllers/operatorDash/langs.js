module.exports = ['$scope',
    function($scope) {

        // $scope.saveOperatorLangs = function() {
        //     console.log($scope.lang);
        //     $scope.config.langs = $scope.selected_items;
        //     $scope.operator.langs = $scope.selected_items;
        // }

    }
]
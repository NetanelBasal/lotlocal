// module.exports = ['$scope', 'operator', 'promoService',
//     function($scope, operator, promoService) {
//         $scope.operator = operator.data[0];

//         $scope.updatePromos = function() {

//              operatorService.updatePromos($scope.operator.id, $scope.operator).then(function(res) {
//                  $scope.operatorUpdated = true;
//              }, function() {
//                  $scope.operatorFailed = true;
//              });
//         };
//     }
// ];
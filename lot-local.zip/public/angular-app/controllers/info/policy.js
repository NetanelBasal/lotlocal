module.exports = ['$scope',
function($scope) {

}
]
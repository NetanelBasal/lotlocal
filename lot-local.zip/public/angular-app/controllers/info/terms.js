module.exports = ['$scope',
function($scope) {
  // $scope.notSub = function(p) {
  //   return /Welcome Bonus/.test(p) == false;

  // }
}
]